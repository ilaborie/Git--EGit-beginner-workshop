package org.eclipsecon.hello;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.MessageFormat;

/**
 * Just the main
 */
public class Main {

    /**
     * Main method
     * 
     * @param args
     *            arguments (not used)
     * @throws IOException 
     */
    public static void main(String[] args) throws IOException {
        System.out.println("Hello World!");
        System.out.println("Hello EclipseCon!");
        System.out.println("What's your name?");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String name = br.readLine();
        System.out.println(MessageFormat.format("Hi {0}!",name));
    }
}
