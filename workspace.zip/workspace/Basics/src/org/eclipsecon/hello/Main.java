package org.eclipsecon.hello;

/**
 * Just the main
 */
public class Main {

    /**
     * Main method
     * 
     * @param args
     *            arguments (not used)
     */
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
