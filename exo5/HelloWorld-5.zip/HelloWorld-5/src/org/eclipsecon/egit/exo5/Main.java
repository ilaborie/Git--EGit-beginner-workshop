package org.eclipsecon.egit.exo5;

/**
 * The Main class
 */
public class Main {
	
	/**
	 * Program entry point
	 * @param args arguments (Optional
	 */
	public static void main(String[] args) {
		System.out.println("Hello World !");
	}
}
