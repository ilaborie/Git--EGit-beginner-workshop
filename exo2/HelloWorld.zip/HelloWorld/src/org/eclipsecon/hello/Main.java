package org.eclipsecon.hello;

/**
 * Just the main
 */
public class Main {

	/**
	 * Main method
	 * @param args arguments (not used)
	 */
	public static void main(String[] args) {
		GreetingService service = new GreetingService();
		
		System.out.println(service.greeting());
	}
}
