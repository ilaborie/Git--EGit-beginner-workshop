package org.eclipsecon.hello;

/**
 * The great greeting service
 */
public class GreetingService {

	/**
	 * Provide a greeting message
	 * @return the greeting message
	 */
	public String greeting() {
		return "Hello World !";
	}
}
